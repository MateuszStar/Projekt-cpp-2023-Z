#ifndef RESOURCE_H
#define RESOURCE_H

#include <winuser.h>

#define WIN32_ICON_MAIN 1
#define MANIFEST_RESOURCE_ID 1

#endif // RESOURCE_H
